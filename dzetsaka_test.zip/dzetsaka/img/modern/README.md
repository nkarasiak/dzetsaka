Modern icon set used by dzetsaka dashboard (Quick mode)

Source:
- Google Material Design Icons repository
- https://github.com/google/material-design-icons

License:
- Apache License 2.0
- https://github.com/google/material-design-icons/blob/master/LICENSE

Notes:
- Files in this folder are derived 16x16 light-on-dark PNG variants generated from
  the upstream 24dp PNG assets for UI consistency in dzetsaka's dark theme.
