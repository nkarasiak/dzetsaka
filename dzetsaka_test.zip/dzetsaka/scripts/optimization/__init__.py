"""Optimization module for hyperparameter tuning."""
