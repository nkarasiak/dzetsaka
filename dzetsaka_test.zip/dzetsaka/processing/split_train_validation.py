"""Compatibility shim for the migrated split-train-validation algorithm."""

from __future__ import annotations

from dzetsaka.qgis.processing.algorithms.split_train_validation import SplitTrain

__all__ = ["SplitTrain"]
