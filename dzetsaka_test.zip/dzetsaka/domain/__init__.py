"""Domain layer for dzetsaka - contains business logic, models, and exceptions."""
